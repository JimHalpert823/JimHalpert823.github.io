QWERTY CHALLENGE — FIRST WEBSITE VERSION

FILES
- index.html: complete responsive landing page with the existing game embedded.
- game.html: original standalone game file, kept separately for editing.
- privacy.html and terms.html: starter drafts; review and customize before public launch.

PREVIEW
Open index.html in a modern browser. The game runs locally in the page; no server is required for a preview.

PUBLISHING
This is a static website. A straightforward first hosting option is Cloudflare Pages:
1. Create/sign in to a Cloudflare account.
2. Open Workers & Pages, then create a Pages project using direct upload (the dashboard wording may change).
3. Upload the contents of this folder (not the ZIP itself if the uploader asks for files).
4. After deployment, test the live URL on desktop and phone.
5. Connect a domain you own in the Pages custom-domain settings.

BEFORE PUBLIC LAUNCH
- Replace hello@yourdomain.com and the contact placeholders with a real business contact.
- Review the privacy and terms drafts for your actual business and jurisdiction.
- Check the business name, domain and trademarks before investing in branding.
- Test the game on common mobile browsers.
- Add a real privacy/consent setup before installing analytics or advertising.
- Do not advertise leaderboards, saved accounts, subscriptions or prizes yet: this version does not include them.

CURRENT LIMITATIONS
- Game scoring and session stats run in the browser.
- No accounts, cloud saves, server-verified leaderboard, payment processing, subscription system, ad placement or analytics are connected.
- Scores can be modified by a technically capable visitor; do not use this version for prize competitions.
- The game iframe has a fixed responsive height and may need adjustment if the game interface changes.
